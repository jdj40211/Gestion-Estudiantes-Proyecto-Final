package com.proyectofinal;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

public class ExportarDatos {
    public void exportarEstudiantes(List<Estudiante> listaEstudiantes, String nombreArchivo) {
        try {
            FileWriter writer = new FileWriter(nombreArchivo);

            for (Estudiante estudiante : listaEstudiantes) {
                String linea = estudiante.getNombre() + "," + estudiante.getIdentificacion() + "," + estudiante.getEdad() + "," + estudiante.getCarrera() + "\n";
                writer.write(linea);
            }

            writer.close();
            System.out.println("Los datos se han exportado correctamente.");
        } catch (IOException e) {
            System.out.println("Error al exportar los datos: " + e.getMessage());
        }
    }
}
