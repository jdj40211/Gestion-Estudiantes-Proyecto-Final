package com.proyectofinal;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

public class Persistencia {
    public static void guardarEstudiantes(List<Estudiante> listaEstudiantes) {
        ExportarDatos exportador = new ExportarDatos();
        exportador.exportarEstudiantes(listaEstudiantes, "Estudiantes.txt");
    }

    public static void guardarEstudiantes(Estudiante estudiante) {
        FileWriter writer = null;
        PrintWriter pw = null;

        try {
            writer = new FileWriter("Estudiantes.txt", true);
            pw = new PrintWriter(writer);
            pw.println(estudiante + "\n");
        } catch (IOException exception) {
            System.err.println("Error abriendo el archivo");
        } finally {
            try {
                if (writer != null) {
                    writer.close();
                }
            } catch (Exception e2) {
                e2.printStackTrace();
            }
        }
    }
}
